# API Library: ForEachHealth_InHomeNPVisitApp_Assessments

## Conventions
- APIs are grouped as API-### with operations OP-###.
- All write operations support idempotency keys.
- All endpoints require TLS and authorization.

---

## API-001 Identity & Access
- **OP-001 Authenticate / Token**
  - Purpose: OIDC login and token issuance
  - Inputs: username/password or SSO assertion, MFA step
  - Outputs: access_token, refresh_token, expires_in
- **OP-002 Refresh Token**
- **OP-003 Revoke Session**

## API-002 Visits & Mobile Sync
- **OP-002 Get Pre-Visit Bundle**
  - Inputs: visit_id
  - Outputs: member summary + history + plan targets + required checklist + config versions
- **OP-003 List Visits**
- **OP-004 Save Draft Delta**
  - Inputs: visit_id, draft_patch, client_version, idempotency_key
- **OP-005 Get Draft**
- **OP-006 Finalize Visit**
  - Validates gating server-side; returns finalized_version_id
- **OP-007 Get Sync Status**

## API-003 Rules, Forms, and Configuration
- **OP-010 Evaluate Rules**
  - Inputs: visit_id, facts
  - Outputs: recommendations with RULE ids + rationale
- **OP-011 Get PlanPack + RulePack (versioned)**
- **OP-012 Get Instrument Definitions (versioned)**
- **OP-013 Get Measure Definitions (versioned)**
- **OP-014 Get Unable-to-Assess Reason Sets (versioned)**

## API-004 Integrations & Exports
- **OP-020 Queue EMR Submission**
  - Inputs: visit_id, finalized_version_id
- **OP-021 Get EMR Submission Status**
- **OP-030 Queue Export Generation**
- **OP-031 Get Export Download Link (time-limited)**
- **OP-032 List Exports by Visit**

## API-005 Care Plan & Tasks
- **OP-040 Create/Update Tasks**
- **OP-041 List Tasks**
- **OP-042 Update Task Outcome**

## API-006 Supervisor Review
- **OP-050 Submit Review Decision**
  - Decision: APPROVE or REQUEST_CORRECTION with reasons
- **OP-051 List Review Queue**

## API-007 Admin Configuration
- **OP-060 Upsert PlanPack**
- **OP-061 Publish Config Version**
- **OP-062 Upsert Instrument Definition**
- **OP-063 Upsert Measure Definition**
- **OP-064 Upsert RulePack**

## API-008 Audit & Compliance
- **OP-070 Query Audit Events**
- **OP-071 Export Audit Report**
- **OP-072 Break Glass Access Request/Review**
