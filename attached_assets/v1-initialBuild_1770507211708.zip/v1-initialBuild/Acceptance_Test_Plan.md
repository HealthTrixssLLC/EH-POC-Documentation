# Acceptance Test Plan: ForEachHealth_InHomeNPVisitApp_Assessments

## 1. Scope
Validate end-to-end prototype functionality for in-home NP visits with assessments and HEDIS measures gating, offline workflows, secure sync, FHIR submission, and export generation.

## 2. Test data prerequisites
- At least 3 test members:
  1. No required HEDIS measures (assessments only)
  2. 3 required HEDIS measures
  3. Mix of measures requiring different evidence capture methods
- PlanPack configured with required instruments and a structured reason set
- Test EMR FHIR endpoint available (can be a mock server)

## 3. Test cases

### AT-001 Offline prefetch and pre-visit view
Steps:
1. NP logs in, selects visit, prefetches bundle
2. Enable airplane mode
3. Open pre-visit summary
Expected:
- Pre-visit summary loads from encrypted local storage
- Required checklist visible with correct items

### AT-002 Complete assessments with deterministic scoring
Steps:
1. Run PHQ-9 in Assessment Runner
2. Verify score and interpretation
Expected:
- Score stored with instrument version
- Server recompute matches on finalize

### AT-003 Unable-to-assess reason capture
Steps:
1. Select a required HEDIS measure
2. Mark unable to assess and select structured reason
Expected:
- Finalization gating considers this satisfied
- Reason code stored with versioned reason set id

### AT-004 Finalization gating blocks signature when incomplete
Steps:
1. Leave one required assessment incomplete with no reason
2. Attempt finalize
Expected:
- Finalize blocked
- UI deep-links to missing item

### AT-005 Offline finalize then sync and submit
Steps:
1. Complete checklist
2. Finalize offline
3. Restore network
Expected:
- Sync transitions to SYNCED_TO_SERVER
- Backend queues EMR submission and export jobs
- Status visible on web visit detail

### AT-006 FHIR bundle submission success path
Steps:
1. Use a mock FHIR endpoint that returns 200
Expected:
- EMR submitted status = SUCCESS
- Resource ids persisted

### AT-007 Export generation and secure download audit
Steps:
1. Generate export
2. Download export from web
Expected:
- Time-limited download link works
- EXPORT_DOWNLOADED audit event recorded

### AT-008 Supervisor review and correction request
Steps:
1. Supervisor requests correction with comment
2. NP sees correction flag and creates addendum
Expected:
- Review decision persisted
- Addendum tracked and auditable

## 4. Exit criteria
- All tests AT-001 through AT-008 pass
- No P0 defects open
- Audit log shows PHI access for key actions
