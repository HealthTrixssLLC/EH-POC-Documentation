# App Screen Map: ForEachHealth_InHomeNPVisitApp_Assessments

## Mobile (iOS)
| Screen ID | Name | Primary Users | Triggers | Key Actions |
|---|---|---|---|---|
| SC-001 | Login | NP | App launch | Authenticate, MFA, session resume |
| SC-002 | Visit List | NP | Post-login | Filter/sort visits, select visit, prefetch |
| SC-003 | Pre-Visit Summary | NP | Select visit | Review history/targets/checklist, prefetch offline |
| SC-004 | Identity Verification | NP | Start visit | Verify identity, capture method, proceed |
| SC-005 | Intake Home | NP | Begin documentation | Show checklist, nav to sections, show completion |
| SC-006 | Vitals + Exam | NP | Intake | Capture vitals/exam, validations, provenance |
| SC-007 | Assessment Runner | NP | Checklist item selected | Administer PRAPARE/PHQ/AWV, scoring, save |
| SC-008 | HEDIS Measure Tasks | NP | Checklist item selected | Evidence capture, completion, unable-to-assess |
| SC-009 | Care Plan + Tasks | NP | Intake | Create tasks/referrals, priorities, due dates |
| SC-010 | Review & Finalize | NP | End visit | Gating validation, signature/attestation, finalize |
| SC-016 | Sync Status | NP | Any time | Show draft/sync states, retries, trace ids |

## Web
| Screen ID | Name | Primary Users | Triggers | Key Actions |
|---|---|---|---|---|
| SC-011 | Supervisor Review Queue | Supervisor | Login | Review, approve, request correction |
| SC-012 | Visit Detail | Supervisor/Ops | Select visit | View note, checklist, statuses, download export |
| SC-013 | Care Coordination Workspace | Care Coordinator | Task assigned | Work tasks, outcomes, contacts log |
| SC-014 | Admin Console | Tech Admin | Login | Configure plan packs, instruments, measures, rules |
| SC-015 | Compliance Audit Viewer | Compliance | Login | Audit reports, export logs, break-glass review |

