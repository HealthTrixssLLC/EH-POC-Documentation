# BRD: ForEachHealth_InHomeNPVisitApp_Assessments

Version: v1 (Executed from HT_GeneralDevelopmentPackage_v2)
Date: 2026-02-07

## Source input
This BRD is derived from the attached BRD input.

---

<!-- Regenerated: 2026-02-07 22:08:34 -->

# Business Requirements Document (BRD)
## Project: For Each Health In Home NP Visit Application Suite
Web App and iOS Mobile App for MA and ACA in home clinical visits, documentation, and care coordination

---

## 1. Purpose and goals
For Each Health conducts in home visits for Medicare Advantage (MA) and Affordable Care Act (ACA) plans and submits visit documentation back to health plans. This program must be more than data collection. It must operate as a clinical review process that produces actionable follow up, a care plan, and care coordination outputs.

### Goals
1. Prepare the Nurse Practitioner (NP) before the visit with a complete clinical picture and plan specific priorities  
2. Guide the NP through a dynamic intake that adapts to patient history, plan targets, and real time findings  
3. Generate real time clinical recommendations for diagnostics and next steps  
4. Produce a medically credible record of the visit, including assessment, findings, and follow up plan  
5. Sync results securely to the web app, transmit to an EMR via FHIR, and generate an importable file for EMR ingestion  
6. Operate securely with PHI under HIPAA and HITECH expectations, including offline workflows  

---

## 2. In scope

### Users and context
1. Nurse Practitioner performing an in home visit  
2. Clinical supervisors reviewing quality and outcomes  
3. Care coordination staff managing follow up tasks and referrals  
4. Plan facing operations staff producing submission packages and reports  
5. Technical admin managing users, devices, integrations, and security  

### Core capabilities

#### A. Pre visit view for NP
1. Member identity and visit details  
2. Historical conditions, medications, allergies, recent labs, and prior utilization  
3. Plan target member list items and priorities for the visit  
4. Open care gaps and suspecting prompts supplied by the plan or internal rules  
5. Risk and safety alerts, including medication interactions, fall risk, and red flags  
6. Suggested visit checklist and time plan  

#### A2. Assessment and measure administration (program, plan, and member specific)
1. Support administration of standardized assessments including PRAPARE, PHQ 2, PHQ 9, and Annual Wellness Visit (AWV) assessment components, configurable by plan, program, and visit type  
2. For each member, there will be 0 to many HEDIS measures that must be assessed during the visit lifecycle. These measures must be:
   a. Imported with the member target list and visit context  
   b. Presented in the pre visit view as a structured required list  
   c. Carried into point of care intake as actionable tasks with guided workflows  
   d. Stored as structured results for store and forward, web review, and downstream submission  
3. Each required assessment or HEDIS measure must include:
   a. Measure or assessment identifier  
   b. Due status or eligibility context if provided by the plan  
   c. Required evidence type and allowable capture methods  
   d. Completion status and timestamp  
   e. Assigned performer and completion context (in home, telephonic, external record, HIE retrieval)  
4. Prior to chart signature and finalization, the NP must either complete each required assessment or measure or provide a structured unable to assess reason for each required item  
5. Structured reasons must be standardized and configurable to support OKE evaluation reporting and auditability

#### B. Dynamic intake and clinical decision support
1. Adaptive form engine that changes questions, sections, and tasks based on  
   a. Patient history and known conditions  
   b. Plan targets and measure requirements  
   c. Current in visit inputs including vitals, symptoms, exam findings, and patient reported outcomes  
2. Real time recommendations for diagnostics and follow up actions  
   a. Suggested screenings, labs, and assessments to consider  
   b. Suggested referrals and escalation rules  
   c. Safety checks and contraindications  
3. Medical record format outputs  
   a. Structured clinical note sections such as chief complaint, HPI, ROS, exam, assessment, plan  
   b. Coding and problem list capture for downstream use  
   c. Evidence capture with provenance and timestamps  

#### C. End of visit outputs and submission artifacts
When the NP completes the visit, the system must produce all of the following  
1. Local storage of findings and form data on device for offline continuity  
2. Web app storage and availability for clinical review and operations  
3. Transmission to EMR using FHIR resources through an EMR API  
4. A downloadable file that can be imported into the EMR  

#### D. Care plan and care coordination
1. Generate a care plan and tasks for follow up, including owner, due date, priority, and status  
2. Support referrals and handoffs to PCP, specialists, behavioral health, pharmacy, and social services  
3. Track attempted contacts, completed follow ups, and outcomes  
4. Provide supervisor review and sign off workflows where required  

#### E. Compliance and security
1. HIPAA and HITECH aligned security controls for PHI  
2. Access controls by role and least privilege  
3. Audit trails for all PHI access and changes  
4. Encryption in transit and at rest, including encrypted on device storage  
5. Secure authentication for web and mobile, including MFA and device security controls  
6. Data retention and deletion policies aligned with client and regulatory expectations  
7. Business associate support, including BAA readiness and vendor risk management artifacts  

---

## 3. Out of scope for the prototype
1. Full payer submission workflows for all downstream formats and all plan specific variants  
2. Full scheduling and route optimization  
3. Complex revenue cycle billing workflows beyond basic export of structured visit content  
4. Full analytics and reporting suite beyond minimal operational dashboards  

---

## 4. Key workflows

### Workflow 1: Pre visit preparation
1. NP logs in securely  
2. NP selects scheduled visit  
3. System displays member profile, plan targets, prior history, and visit checklist  
4. NP confirms pre visit plan, required supplies, and safety considerations  

### Workflow 2: In home intake and clinical review
1. NP begins visit and confirms patient identity  
2. System displays the member specific checklist of required assessments and HEDIS measures for this visit and guides the recommended order of completion  
3. Dynamic intake form guides the NP through required and conditional steps, including embedded assessment instruments (PRAPARE, PHQ 2, PHQ 9, AWV) and HEDIS measure evaluation prompts  
4. System updates recommendations based on inputs and highlights remaining incomplete required assessments and measures  
5. NP documents findings in structured format and completes or documents a structured unable to assess reason for each required assessment or measure  
6. NP reviews generated care plan and confirms follow up tasks with the patient

### Workflow 3: Close out and sync
1. Prior to signature, system validates that all required assessments and HEDIS measures are either completed or have a structured unable to assess reason. If not, the chart cannot be finalized  
2. App stores locally and syncs to web when connectivity exists  
3. App sends FHIR payload or bundle to EMR API  
4. App generates EMR import file and makes it available in web app for download  
5. Care coordination tasks are created and assigned

### Workflow 4: Clinical review and care coordination
1. Supervisor reviews note for completeness and quality  
2. Care coordinator executes tasks and documents outcomes  
3. Plan facing team packages required outputs for client consumption  

---

## 5. Business rules
1. No visit can be finalized without required identity verification steps  
2. Required fields vary by plan and by visit type and must be configurable  
3. Recommendations must always be explainable, with rationale and source rule reference  
4. Providers must be able to override recommendations with a documented reason  
5. Offline work must be supported with a clear sync status and conflict handling  
6. Every data element must carry provenance metadata including who entered it, when, and source type
7. A visit cannot be finalized or signed unless every required assessment and HEDIS measure for that member is either completed or has a structured unable to assess reason captured  
8. Required assessments and HEDIS measures are driven by plan configuration plus member specific import inputs and must be auditable by source and version  
9. Assessment scoring, thresholds, and interpretation guidance must be versioned and linked to the visit record for OKE evaluation reporting  

---

## 6. Requirements by module

### Pre visit module
1. Display plan target items and gaps as structured, filterable lists  
2. Display problem list, medications, allergies, prior labs, and recent encounters  
3. Display risk flags and safety prompts  
4. Support patient contact history and special instructions
5. Display a Required Assessments and Measures checklist including PRAPARE, PHQ 2, PHQ 9, AWV components, and member specific HEDIS measures with status

### Assessments and measures module
1. Admin can configure and version assessment instruments including PRAPARE, PHQ 2, PHQ 9, and AWV components  
2. Admin can configure and version HEDIS measure definitions used by the application, including measure identifiers, evidence expectations, and allowable capture methods  
3. System generates a member specific required assessment and HEDIS measure checklist per visit based on import data and plan rules  
4. Mobile supports point of care administration with scoring and validations where applicable  
5. Mobile supports structured unable to assess reasons per assessment or measure  
6. Web app supports supervisor review of assessment completeness, results, and unable to assess reasons  


### Dynamic intake module
1. Form engine supports conditional logic, scoring, and branching  
2. Supports templates by visit type and plan  
3. Supports insertion of patient specific context into prompts and sections  
4. Supports quick capture for vitals and common exam components  
5. Supports attachments if needed such as photos, with strict controls and consent support
6. Support embedded assessment instruments and HEDIS measure workflows with scoring, branching, and structured evidence capture  
7. Highlight incomplete required assessments and measures continuously during intake and at close out  

### Clinical note module
1. Produces human readable clinical note  
2. Produces structured data for downstream integration  
3. Supports e signature and attestation statements
4. Include an Assessments and Measures section listing all required items, completion status, results, and unable to assess reasons  

### Care plan and coordination module
1. Generates tasks and follow ups  
2. Tracks outcomes and status changes  
3. Supports escalation triggers  

### Integrations module
1. EMR API integration using FHIR  
2. EMR import file generation  
3. Plan file ingestion for target member list and priorities  

### Admin module
1. User and role management  
2. Device management and session control  
3. Form template management and plan configuration  
4. Integration configuration and monitoring  
5. Audit log access for compliance roles  

---

## 7. Reporting needs for the prototype
1. Visit completion status and sync status  
2. Required field completeness  
3. Care plan task creation and closure counts  
4. Basic quality review queue and outcomes  

---

## 8. Success metrics
1. Reduction in incomplete or rejected visit packages  
2. Increased closure of follow up tasks within SLA  
3. Improved time to complete documentation without reducing quality  
4. High NP usability scores and low error rates in intake  
5. Reliable EMR transmission success rate and low reconciliation burden  

---

## 9. Stakeholders
1. NPs and clinical supervisors  
2. Care coordination team  
3. Operations and client success  
4. Compliance and security  
5. Engineering and product  

---

## 10. Acceptance criteria for prototype
1. NP can complete a visit offline and sync later  
2. Pre visit view loads plan targets and patient history for a selected member  
3. Dynamic form changes based on at least three categories of rules  
   a. Patient history  
   b. Plan targets  
   c. In visit inputs  
4. Generates a structured clinical note and care plan  
5. Sends a valid FHIR payload to a test EMR endpoint  
6. Generates an importable file and makes it downloadable in the web app  
7. Enforces role based access and logs all PHI access events  
8. Encrypts local device data and uses TLS for all network communications
11. Assessment and measures gating works: chart cannot be signed until all required assessments and member specific HEDIS measures are completed or have structured unable to assess reasons  

