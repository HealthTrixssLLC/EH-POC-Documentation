# Branding Guidelines: ForEachHealth_InHomeNPVisitApp_Assessments

This module must follow HT branding rules below. This file is included to ensure UI and collateral are consistent.

## Canonical HT color palette
- Dark Blue Accent: #2E456B
- Orange Accent: #FEA002
- Dark Teal Accent: #277493
- Tan Accent: #F3DBB1
- Light Orange Accent: #FFCA4B
- Light Green Accent: #88ABA2
- Light Teal Accent: #67AABF
- Light Grey Accent: #ABAFA5

## Usage rules
1. Do not alter the HT logo (no stretching, recoloring, or shadow effects unless official variants exist).
2. Primary call-to-action buttons use Orange Accent (#FEA002); secondary actions use Dark Teal (#277493).
3. Primary navigation surfaces use Dark Blue (#2E456B) with neutral backgrounds for content.
4. Ensure accessible contrast for all text and interactive elements.

## Component guidance (prototype)
- Cards: light neutral background, subtle borders, ample spacing.
- Checklist status chips: use neutral + accent color for state, with text labels (not color-only).
- Alerts: use Tan for warnings and Dark Teal for informational messages.

## Typography and layout
- Prefer clean sans-serif fonts (system defaults acceptable for prototype).
- Use consistent spacing and predictable grid layout.
