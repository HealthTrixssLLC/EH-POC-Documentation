# FHIR Mappings By Workflow: ForEachHealth_InHomeNPVisitApp_Assessments

## Conventions
- Use US Core R4 profiles when available (US Core 6.1.0 pinned)
- Bundle submission is preferred for EMR integration
- Every resource includes provenance where supported and is linked back to the visit id

---

## WF-001 Pre-Visit Preparation
**Reads (from plan/EMR/import sources):**
- Patient (member identity reference)
- Condition (problem list/history if provided)
- MedicationStatement / AllergyIntolerance (history)
- Prior Encounters/Observations if available

**No writes** in WF-001.

---

## WF-002 In-Home Intake + Assessments/Measures
**Writes (draft state on platform; final FHIR emitted at WF-003):**
- Observation: vitals (BP, BMI, weight, etc) and key findings
- Condition: assessed/confirmed problems
- Questionnaire + QuestionnaireResponse: PRAPARE, PHQ-2, PHQ-9, AWV components (when supported)
- Observation: scored results (PHQ-9 total, risk flags) when EMR prefers discrete results
- CarePlan + Task: follow-up plan drafts

---

## WF-003 Finalize + EMR Submit + Export
**Writes to EMR (transaction bundle):**
- Encounter: the visit
- Practitioner (+ PractitionerRole): NP identity and role
- Location / Organization: visit location and owning org
- Patient: reference (create only if required by EMR)
- Observation: vitals and discrete findings
- Condition: diagnoses / assessed problems
- MedicationStatement / AllergyIntolerance: if captured
- CarePlan + Task: follow-up plan and care coordination tasks
- DocumentReference or Composition: clinical note document
- Questionnaire / QuestionnaireResponse: standardized assessment payloads when supported

**Export file:**
- FHIR Bundle JSON (transaction or collection) generated from finalized record

---

## WF-004 Clinical Review + Care Coordination
**Platform updates (may or may not map to EMR depending on program):**
- Task status updates (FHIR Task) if EMR supports task sync
- CarePlan updates (FHIR CarePlan) if shared with EMR
- DocumentReference addendum (or Composition amendment) for corrections

---

## WF-005 Configuration & Versioning
No FHIR writes. Configuration artifacts are internal.

---

## WF-006 Compliance & Audit
No FHIR writes. Audit logs are internal but may be exported as compliance reports (non-FHIR).

