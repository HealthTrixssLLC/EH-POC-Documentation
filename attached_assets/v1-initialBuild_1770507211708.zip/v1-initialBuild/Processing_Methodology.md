# Processing Methodology: ForEachHealth_InHomeNPVisitApp_Assessments

## 1. Offline-first sync state machine (mobile)
States:
1. DRAFT_LOCAL_ONLY
2. READY_TO_SYNC
3. SYNCED_TO_SERVER
4. EMR_SUBMITTED
5. EXPORT_GENERATED
6. ERROR (with retry + trace id)

Rules:
- Configuration is server-authoritative (server wins)
- Clinical content is versioned; edits after finalize become addenda
- Sync uses idempotency keys per operation and per visit version

## 2. Required Assessments & Measures checklist generation
Inputs:
- PlanPack (plan/program/visit_type)
- Imported member-specific required HEDIS measures (0..n)
- Program-required assessments (PRAPARE, PHQ-2, PHQ-9, AWV components)
Process:
1. Build checklist items with stable ids (REQ-###)
2. Attach required evidence types and allowable capture methods
3. Set initial status = NOT_STARTED
4. Persist checklist with:
   - config versions (planpack_version, instrument_versions, measure_versions)
   - audit trail of who generated and when

## 3. Unable-to-assess reasons (standardized)
- Stored as a versioned ReasonSet per plan/program
- Each required item can be marked UNABLE_TO_ASSESS only with:
  - reason_code, reason_display, free_text_optional, timestamp, performer_id
- Examples: Patient declined, Not clinically appropriate, Safety issue, Unable to obtain information, Patient not present, Equipment unavailable

## 4. Deterministic scoring for instruments (prototype)
- Scoring computed locally on iOS using versioned config
- Persist:
  - raw responses
  - computed score
  - scoring_algorithm_id and version
  - interpretation band (e.g., PHQ-9 severity)
- Validation:
  - recompute score server-side on finalize; block finalize if mismatch

## 5. Recommendation engine (rules)
RulePack structure:
- Rule ID (RULE-###)
- Version
- Trigger conditions (facts)
- Suggested action(s)
- Rationale text
- Required follow-up (optional)
Processing:
- Evaluate on key events (vitals saved, assessment completed, measure completed)
- Log each recommendation event:
  - triggering facts snapshot hash
  - displayed_to_user_at timestamp
  - accepted/rejected with override reason

## 6. Finalization gating
A visit can be finalized only when:
1. Identity verification completed
2. All plan-required fields complete
3. Every required checklist item is either:
   - COMPLETE, or
   - UNABLE_TO_ASSESS with structured reason
4. Signature and attestation captured

## 7. EMR submission mapping (FHIR)
- Build a FHIR transaction bundle from the finalized record
- Run FHIR validation (lightweight) before submit
- Persist:
  - bundle_hash
  - submit_attempts
  - EMR response status and resource ids
  - error categories (validation, auth, network, business)

## 8. Export generation
- Generate export only from finalized record
- Default export: FHIR Bundle JSON file
- Store in object storage encrypted at rest; provide time-limited signed URL
- Log every download in audit log

## 9. Audit logging
Events to capture (minimum):
- PHI_VIEW (member banner, visit detail)
- PHI_EDIT (field changes with old/new hashes)
- EXPORT_GENERATED / EXPORT_DOWNLOADED
- EMR_SUBMIT_ATTEMPT / EMR_SUBMIT_SUCCESS / EMR_SUBMIT_FAILURE
- BREAK_GLASS_USED
Each event includes:
- user_id, role, patient_id, visit_id, timestamp, device_id, ip (web), trace_id

