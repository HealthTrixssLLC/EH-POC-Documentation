# Replit Upload Checklist: ForEachHealth_InHomeNPVisitApp_Assessments

## Goal
Provide a predictable Replit-ready structure for building the web app + API and for storing generated artifacts.

## 1. Repo layout (recommended)
- /apps/web
- /apps/api
- /packages/shared (types, validation, FHIR helpers)
- /docs (keep this packet as source-of-truth)
- /infra (scripts for local/dev setup)

## 2. Environment variables (minimum)
- AUTH_ISSUER_URL
- AUTH_CLIENT_ID
- AUTH_CLIENT_SECRET
- API_BASE_URL
- DB_URL
- OBJECT_STORAGE_BUCKET
- OBJECT_STORAGE_ACCESS_KEY
- OBJECT_STORAGE_SECRET_KEY
- FHIR_EMR_BASE_URL
- FHIR_EMR_AUTH_TOKEN (or client credentials fields)
- AUDIT_LOG_RETENTION_DAYS

## 3. First run checks
1. Web app boots and can reach API health endpoint
2. Login flow returns tokens and enforces RBAC
3. Seed PlanPack + instrument definitions + reason sets
4. Create a test visit and verify prefetch bundle works

## 4. Security checks (prototype)
- TLS enforced (Replit default for hosted endpoints)
- No PHI in client logs
- Audit event emitted for PHI view and export download
- Local iOS storage encryption validated (platform controls + app layer)

## 5. Deliverable placement
- Keep this packet in /docs/ForEachHealth_InHomeNPVisitApp_Assessments_Packet/ and do not modify the originals
- Generated code should reference API-### and OP-### ids in docstrings and comments where applicable
