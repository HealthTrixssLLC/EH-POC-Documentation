# SAA: ForEachHealth_InHomeNPVisitApp_Assessments
Version: v1 (Executed)
Date: 2026-02-07

## 1. Summary
This Solution Architecture Artifact (SAA) defines the executable development plan for a dual-application suite (iOS + Web) supporting Medicare Advantage and ACA in-home Nurse Practitioner visits, with a configuration-driven assessment and HEDIS measures engine, offline-first capture, secure sync, and downstream FHIR integration.

## 2. Architectural goals
1. Offline-first mobile capture with encrypted local persistence and deterministic sync state machine
2. Configuration-driven assessments, HEDIS measure checklists, and rule packs (plan/program/visit-type specific), versioned and auditable
3. Dual-output clinical documentation: human-readable note plus structured FHIR-mapped data
4. PHI security controls aligned to HIPAA/HITECH expectations (RBAC, audit trails, encryption)
5. Robust integration pipeline: EMR FHIR submission queue + secure export generation

## 3. High level architecture
```mermaid
flowchart LR
  subgraph Mobile[iOS Mobile App]
    M1[Pre-Visit Prefetch]
    M2[Offline Intake + Assessments]
    M3[Finalize + Sign]
    M4[Sync Agent]
  end

  subgraph Web[Web App]
    W1[Review Queue]
    W2[Care Coordination]
    W3[Admin Console]
    W4[Exports + Download]
  end

  subgraph API[Backend/API]
    A1[Auth + RBAC]
    A2[Visit Service]
    A3[Rules + Forms Service]
    A4[Clinical Documentation Service]
    A5[Integration Service]
    A6[Audit/Logging Service]
  end

  subgraph Data[Data Stores]
    D1[(PHI DB)]
    D2[(Config DB)]
    D3[(Object Storage: Exports/Attachments)]
    D4[(Queue: EMR Submit + Export Jobs)]
    D5[(Immutable Audit Log)]
  end

  Mobile -->|TLS| API
  Web -->|TLS| API
  API --> Data
  A5 -->|FHIR| EMR[(EMR FHIR Endpoint)]
```

## 4. Key domain model (logical)
- Member
- Visit
- RequiredItemChecklist (Assessments + Measures)
- AssessmentInstrumentDefinition (versioned)
- AssessmentResponse (scored; references instrument version)
- MeasureDefinition (versioned)
- MeasureEvaluationResult (evidence metadata + completion state)
- ClinicalNote (rendered + structured)
- CarePlan + Tasks
- IntegrationTransaction (EMR submit, export jobs)
- AuditEvent (PHI access + change log)

## 5. Security posture (minimum for prototype)
- OAuth2/OIDC, short-lived access tokens, refresh tokens on mobile using secure storage
- MFA for web; configurable for mobile
- RBAC with least-privilege and break-glass policy (with justification capture)
- TLS 1.2+ in transit; encryption at rest for all PHI stores and object storage
- Encrypted on-device database; inactivity lock + biometric/passcode gate
- Audit logging for every PHI access + every clinical record change (immutable retention store)

## 6. Integration pattern
- Mobile finalizes visit -> backend validates gating -> queues:
  - EMR Submission Job (FHIR Bundle transaction preferred)
  - Export Generation Job (FHIR Bundle JSON file for import)
- Integration jobs persist trace id, request/response hashes, and EMR resource ids for reconciliation.

## 7. Environments and deployment assumptions (prototype)
- Replit: web app + API services (or monorepo with separate services)
- Object storage: S3-compatible (or Replit storage abstraction) for exports
- Queue: managed queue (or DB-backed job table for prototype)
- iOS: TestFlight distribution for NP testers

## 8. Open decisions (prototype defaults)
- FHIR note representation: DocumentReference vs Composition (select per target EMR)
- Assessment storage: Questionnaire/QuestionnaireResponse vs Observation-based results (support both; prefer Q/Qr when EMR supports)
