# Screen Specs: ForEachHealth_InHomeNPVisitApp_Assessments

## Common UX rules
- Always show checklist completion state and what is blocking finalization
- Offline-first: every screen shows sync indicator and last sync time
- All data capture fields store provenance metadata
- Apply HT branding palette and spacing rules (see Branding Guidelines)

---

## SC-003 Pre-Visit Summary (iOS)
**Users:** NP  
**Purpose:** Provide a complete clinical picture and required checklist for the visit.

### Data displayed
- Member banner: name, DOB, member id, address, phone
- Visit details: scheduled window, travel notes, safety notes
- Plan priorities: target conditions, suspecting prompts, care gaps
- Required Assessments & Measures checklist:
  - PRAPARE, PHQ-2, PHQ-9, AWV components
  - Member-specific HEDIS measures (0..n)
  - Status: Not started / In progress / Complete / Unable to assess
- History: conditions, meds, allergies, key labs and utilization highlights
- Risk flags: fall risk, med interactions, red flags

### Actions
- Prefetch for offline
- Start visit -> SC-004
- Open checklist item -> SC-007/SC-008

### Validations
- Prefetch requires at least one successful bundle download
- Show warnings if data missing or stale

---

## SC-007 Assessment Runner (iOS)
**Purpose:** Administer standardized assessment instruments and compute deterministic scores.

### Controls
- Instrument selector (from required checklist)
- Question list (sectioned), response types, required rules
- Real-time scoring panel with interpretation guidance (versioned)
- Save draft, Complete, Unable to assess

### Data written
- QuestionnaireResponse-like structure internally with:
  - instrument_id, instrument_version
  - responses, computed_score, interpretation
  - performer_id, completed_at
  - source_context: in_home, telephonic, external_record, HIE_retrieval

### Validations
- Enforce required questions for completion
- Score validation: computed score must match rule pack derivation
- Cannot finalize visit if required instrument incomplete without unable-to-assess reason

---

## SC-008 HEDIS Measure Tasks (iOS)
**Purpose:** Guide evidence capture for each required HEDIS measure item.

### Controls
- Measure card with identifier and due context
- Evidence capture method selector:
  - In home visit evidence
  - Member-reported
  - External record
  - HIE retrieval
- Evidence metadata fields (who/when/source)
- Completion state and unable-to-assess reason (structured)

### Validations
- Enforce evidence metadata completion when measure marked complete
- Enforce structured reason when unable to assess

---

## SC-010 Review & Finalize (iOS)
**Purpose:** End-of-visit gating, signature, and final submission.

### Checklist gating panel
- Shows every required item with status
- Shows blockers with deep links
- Shows required fields missing by plan

### Signature/attestation
- Attestation statement text (configurable)
- Signature capture (typed + biometric confirmation, or signature pad)
- Timestamp and device id

### Finalize behavior
- If offline, finalization allowed and sync queued; EMR submission queued after sync
- If online, finalize and immediately sync

---

## SC-012 Visit Detail (Web)
**Purpose:** Unified view for supervisor, ops, and compliance-appropriate viewing.

### Sections
- Visit status timeline: Draft -> Finalized -> Synced -> EMR Submitted -> Export Generated
- Clinical note viewer (rendered)
- Structured data tabs:
  - Assessments (responses, scores, versions)
  - Measures (evidence, completion, unable-to-assess)
  - Care plan and tasks
- Actions:
  - Approve / request correction (supervisor)
  - Generate export / download export (ops)
  - View audit events (authorized roles)

---

## SC-014 Admin Console (Web)
**Purpose:** Configure plan packs, assessments, measures, and rule packs.

### Admin objects
- PlanPack:
  - plan_id, program_id, visit_type
  - required_assessments list
  - required_measures list (HEDIS)
  - rule_pack_id + version
  - unable_to_assess_reason_set_id
- AssessmentInstrumentDefinition (versioned)
- MeasureDefinition (versioned)
- RulePack (versioned)
- Publish workflow with audit trail

