# TRD: ForEachHealth_InHomeNPVisitApp_Assessments

Version: v1 (Executed from HT_GeneralDevelopmentPackage_v2)
Date: 2026-02-07

## Source input
This TRD is derived from the attached TRD input.

---

<!-- Regenerated: 2026-02-07 22:08:34 -->

# Technical Requirements Document (TRD)
## Project: For Each Health In Home NP Visit Application Suite
Web App and iOS Mobile App for MA and ACA in home clinical visits, documentation, and care coordination

---

## 1. System overview
The solution is a dual application suite:
1. iOS mobile app optimized for in home use, offline capable, fast data capture  
2. Web application for clinical review, operations, admin, and download of artifacts  

### Core design principles
1. Offline first on mobile with secure local persistence  
2. Configuration driven dynamic forms and plan specific rule packs  
3. Dual output model:
   a. Human readable clinical note  
   b. Structured data mapped to FHIR  
4. Strong security posture aligned to HIPAA and HITECH expectations  
5. Full auditability and provenance metadata  

---

## 2. Proposed architecture

### High level components
1. Mobile iOS app  
2. Web app frontend  
3. API layer  
4. Rules and forms service  
5. Clinical documentation service  
6. Integration service for EMR and exports  
7. Identity and access management  
8. Audit and logging service  
9. Data store  

### Recommended pattern
1. Backend as a set of services behind an API gateway  
2. Event driven processing for exports and EMR submissions  
3. Central configuration for plan rules, form templates, and required fields  

---

## 3. Data domains and storage

### Primary entities
1. Member  
2. Visit  
3. Intake responses  
4. Clinical note  
5. Findings and observations  
6. Diagnoses and conditions  
7. Medications and allergies  
8. Care plan and tasks  
9. Attachments and media if enabled  
10. Integration transactions and export artifacts  
11. Audit events  

12. Assessment instrument definition (versioned)  
13. Assessment response and score  
14. Measure requirement (member specific, visit specific)  
15. Measure evaluation result and evidence metadata  
16. Unable to assess reason (structured, per assessment or measure)  
### Local storage on iOS
1. Encrypted local database for offline data  
2. Record level encryption keys bound to device secure hardware when available  
3. Automatic lockout on inactivity and biometric or passcode gate for app access  
4. Sync state machine:
   a. Draft only local  
   b. Ready to sync  
   c. Synced to server  
   d. EMR submitted  
   e. Export generated  
   f. Error state with retry and support trace id  

### Server storage
1. Encryption at rest using managed keys  
2. Separate storage for PHI versus configuration metadata  
3. Strict tenant or client separation if serving multiple plans or clients  

---

## 4. Security and compliance requirements

### Identity and authentication
1. OAuth 2.0 and OpenID Connect with short lived access tokens  
2. MFA required for web access and configurable for mobile  
3. Support SSO integration with enterprise identity providers when needed  

### Authorization
1. Role based access control with least privilege  
2. Fine grained permissions for viewing, editing, exporting, and integration actions  
3. Break glass access policy if required, with justification capture and enhanced logging  

### Encryption
1. TLS 1.2 or higher for all network traffic  
2. Encryption at rest for all server databases and object storage  
3. Encrypted local storage on device  

### Audit logging
1. Log every PHI access event  
2. Log every change to clinical records with versioning  
3. Log all export generation and EMR submission actions  
4. Immutable log storage with retention policy  
5. Audit reports available to compliance roles  

### Device security
1. Jailbreak detection best effort  
2. Remote wipe capability for app data when device is lost or access is revoked  
3. Prevent screenshots if required by policy  
4. App session timeout and re authentication  

### Operational controls to support HIPAA and HITECH expectations
1. Access controls and unique user identification  
2. Automatic logoff  
3. Integrity controls for records  
4. Transmission security  
5. Breach notification support through logging, monitoring, and incident response procedures  
6. Business associate artifacts and vendor management readiness  

---

## 5. Functional technical requirements

### 5.1 Pre visit view

#### Inputs
1. Member demographics and identifiers  
2. Plan target member list and priorities  
3. Member clinical history data supplied by plan or prior visits  
4. Internal risk rules and prompts  

#### Outputs
1. NP ready view including:
   a. Visit checklist  
   b. Risk flags  
   c. Suspected conditions or care gaps list  
   d. Recommended focus areas  

#### Technical requirements
1. Data caching for offline access after prefetch  
2. Search and filtering by member, address, and visit date  
3. Quick actions for contact and navigation  

---

### 5.2 Dynamic intake and recommendations engine

#### Form template model
1. Sections, questions, response types, and validations  
2. Conditional logic rules  
3. Required versus optional by plan and visit type  
4. Scoring rules and thresholds  
5. Recommendation rules with rationale text  

6. Assessment instrument support for PRAPARE, PHQ 2, PHQ 9, and AWV components including questions, response types, scoring rules, thresholds, and interpretation guidance, all versioned  
7. Measure requirement checklist support for member specific HEDIS measures including required evidence types, allowable capture methods, and completion state tracking  
#### Rule engine requirements
1. Deterministic rules for prototype, configurable and versioned  
2. Every recommendation includes:
   a. Rule id  
   b. Version  
   c. Triggering facts  
   d. Suggested action  
   e. Override reason capture if rejected  

#### Real time behavior
1. Update recommendations on key data entry events  
2. Keep UI responsive under typical visit workloads  
3. Maintain a timeline of decision points for auditability

#### Assessment and measure administration requirements
1. Generate a member specific Required Assessments and Measures checklist at visit creation or import, including 0 to many HEDIS measures plus program assessments (PRAPARE, PHQ 2, PHQ 9, AWV)  
2. Mobile intake UI supports completion of each required item or capture of a structured unable to assess reason  
3. Scoring must be deterministic and based on versioned configuration, storing the exact instrument version with the visit record  
4. Rules engine can trigger follow up recommendations based on assessment results, for example PHQ 9 thresholds driving behavioral health referral prompts and PRAPARE domains driving social services and care coordination tasks  


---

### 5.3 Clinical note generation

#### Note content
1. Standard sections appropriate for an in home NP visit  
2. Structured fields mapped to FHIR resources  
3. Attestation statements and e signature metadata  

4. Assessment and measures section listing required assessments and HEDIS measures, completion status, results and scores, structured unable to assess reasons, evidence source metadata, and timestamps  
#### Technical requirements
1. Generate a human readable note view  
2. Generate a structured representation for storage and integration  
3. Support versioning and amendments with addendum tracking  

---

### 5.4 Local save, sync, and conflict handling

#### Offline first requirements
1. All in visit documentation can be completed without connectivity  
2. Sync retries with exponential backoff  
3. Conflict resolution:
   a. Server wins for configuration  
   b. Record versioning for clinical content  
   c. Prevent concurrent edits where feasible  

---

### 5.5 EMR integration using FHIR

#### FHIR resource targets for prototype
1. Patient for identity reference when required  
2. Encounter for the visit  
3. Practitioner and optionally PractitionerRole  
4. Organization and Location when needed  
5. Observation for vitals and discrete findings  
6. Condition for assessed or confirmed diagnoses and problems  
7. MedicationStatement and AllergyIntolerance for reported medications and allergies if captured  
8. CarePlan and Task for follow up plan and coordination  
9. DocumentReference or Composition for the clinical note, depending on EMR expectation  

10. Questionnaire and QuestionnaireResponse for standardized assessments when supported by the EMR  
11. Observation for scored results and key derived findings when the EMR prefers discrete result storage  
#### Submission pattern
1. Create a FHIR bundle transaction when supported  
2. Store the EMR response and resource ids for reconciliation  
3. Queue submissions if offline and send when online  

4. Persist mappings between assessment results and exported FHIR resources including questionnaire version identifiers and score derivation metadata  
#### Error handling
1. Validation errors surfaced with actionable guidance  
2. Retry safe operations retried automatically  
3. Non retry errors create a support ticket object with trace id and payload hash  

---

### 5.6 Downloadable EMR import file

#### Prototype options
1. FHIR bundle JSON file for import into systems that support file based FHIR ingestion  
2. CDA like document export only if explicitly required later  
3. CSV export for operational use only, not the authoritative medical record  

#### Requirements
1. File generated from the finalized signed visit record  
2. Files encrypted at rest and access controlled  
3. Download links time limited and require authorization  
4. Every download audited  

---

## 6. Web application requirements

### User functions
1. Review visit records  
2. View clinical note and structured findings  
3. Approve or request corrections  
4. Manage care plan tasks and outcomes  
5. Generate and download export files  
6. Monitor EMR submission status  
7. Administer users, roles, forms, and plan configurations  

### Technical requirements
1. Modern responsive UI  
2. Strong authorization checks enforced server side and client side  
3. Tamper resistant audit log views for compliance roles  

---

## 7. API requirements

### API style
1. REST or GraphQL for application operations  
2. Separate integration endpoints for EMR submission queueing  
3. Use idempotency keys for create operations, especially on mobile sync  

### Key endpoints for prototype
1. Auth and token refresh  
2. Member and visit retrieval  
3. Prefetch bundle for offline prep  
4. Form templates and rules retrieval with versioning  
5. Draft save and finalize visit  
6. Generate note and generate export  
7. Submit to EMR and check status  
8. Task management for care plan follow up  
9. Audit log retrieval for authorized roles  

---

## 8. Data validation and quality controls
1. Required field validation by plan configuration  
2. Clinical range validation for vitals and labs where applicable  
3. Consistency checks such as missing identity confirmation or missing signature  
4. Completeness scoring to support supervisor review queues  

5. Finalization gating validation blocks signature if any required assessment or HEDIS measure is neither completed nor has a structured unable to assess reason  
6. Assessment scoring validation ensures computed scores match stored responses and stored instrument version  
7. Measure completeness scoring produces indicators suitable for supervisor queues and OKE evaluation reporting  
---

## 9. Performance and reliability requirements

### Mobile
1. Pre visit view loads within 3 seconds after prefetch  
2. Dynamic form interactions respond within 150 ms for common actions  
3. App operates for full visit duration without network  

### Backend
1. Availability target for prototype hosting: 99.9 percent best effort  
2. Export generation completes within 60 seconds for typical visits  
3. EMR submission processing is queued and resilient  

---

## 10. Observability and monitoring
1. Centralized logs with PHI safe redaction  
2. Metrics for sync success rate, EMR submission success, export generation failures  
3. Alerting on error spikes and integration failures  
4. Trace ids propagated across mobile, API, and integration services  

---

## 11. Compliance documentation deliverables for prototype readiness
1. Security risk assessment summary  
2. Data flow diagram and PHI inventory  
3. Access control matrix and role definitions  
4. Audit log specification and sample reports  
5. Incident response outline and breach notification workflow support  
6. Vendor and hosting controls summary, including encryption and backups  

---

## 12. Prototype build plan

### Phase 1: Foundations
1. Identity, RBAC, audit logging scaffolding  
2. Core data model and visit workflow  
3. Offline storage and sync framework  

### Phase 2: Clinical workflows
1. Pre visit view with plan target ingestion  
2. Dynamic forms with rule driven branching  
3. Note generation and signature  

### Phase 3: Integrations and artifacts
1. FHIR mapping and test endpoint submission  
2. Export file generation and secure download  
3. Web review and care plan tasks  

### Phase 4: Hardening
1. Security validation and penetration testing lite  
2. Reliability testing for offline and sync  
3. Usability testing with NPs  

---

## 13. Definition of done for prototype
1. NP can complete and finalize a visit on iOS  
2. Record syncs to web and can be reviewed and approved  
3. FHIR payload sends successfully to a test EMR endpoint  
4. Import file can be generated and downloaded securely  
5. Full audit trail exists for all PHI actions  
6. Encryption and session controls are implemented on device and server  
7. Configuration driven forms and rules can be updated without a new mobile release within reason for the prototype  

