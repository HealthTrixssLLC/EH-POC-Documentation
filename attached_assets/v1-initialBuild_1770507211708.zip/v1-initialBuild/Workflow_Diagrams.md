# Workflow Diagrams: ForEachHealth_InHomeNPVisitApp_Assessments

## WF-001 Pre-Visit Preparation
```mermaid
sequenceDiagram
  autonumber
  participant NP as Nurse Practitioner
  participant iOS as iOS App
  participant API as Backend API
  participant CFG as Rules/Config Service
  NP->>iOS: Login + Select Visit
  iOS->>API: API-001 OP-001 Authenticate
  iOS->>API: API-002 OP-002 Get Pre-Visit Bundle (idempotent)
  API->>CFG: Load plan pack + required checklist definitions
  CFG-->>API: Versioned config + rule pack
  API-->>iOS: Pre-visit bundle (PHI + checklist + flags)
  iOS-->>NP: Pre-Visit Summary (SC-003)
  iOS->>iOS: Encrypt + store offline cache
```

## WF-002 In-Home Intake + Assessments/Measures
```mermaid
sequenceDiagram
  autonumber
  participant NP as Nurse Practitioner
  participant iOS as iOS App
  participant RE as Rules Engine
  NP->>iOS: Identity Verification (SC-004)
  NP->>iOS: Capture vitals/exam + complete assessments (SC-006/SC-007)
  iOS->>RE: Evaluate rules (API-003 OP-010) with triggering facts
  RE-->>iOS: Recommendations + rationale + rule ids
  NP->>iOS: Complete HEDIS tasks (SC-008) or Unable-to-Assess reason
  iOS-->>NP: Continuous checklist completion status
  iOS->>iOS: Queue draft sync ops if offline
```

## WF-003 Finalize + EMR Submit + Export
```mermaid
sequenceDiagram
  autonumber
  participant NP as Nurse Practitioner
  participant iOS as iOS App
  participant API as Backend API
  participant INT as Integration Service
  participant Q as Job Queue
  participant EMR as EMR FHIR Endpoint
  NP->>iOS: Review & Finalize (SC-010)
  iOS->>iOS: Gating validation (required checklist complete)
  iOS->>API: API-002 OP-006 Finalize Visit (idempotent)
  API->>Q: Enqueue EMR submit (API-004 OP-020)
  API->>Q: Enqueue Export generation (API-004 OP-030)
  Q->>INT: Run EMR Submit Job
  INT->>EMR: FHIR Bundle Transaction
  EMR-->>INT: 200 + resource ids / errors
  INT-->>API: Persist transaction + status
  Q->>INT: Run Export Job
  INT-->>API: Store export artifact + signed URL
  API-->>iOS: Finalize ack + status
```

## WF-004 Supervisor Review + Care Coordination
```mermaid
sequenceDiagram
  autonumber
  participant SUP as Supervisor
  participant WEB as Web App
  participant API as Backend API
  participant CC as Care Coordinator
  SUP->>WEB: Open review queue (SC-011)
  WEB->>API: Fetch visit + completeness indicators
  SUP->>WEB: Approve or request correction
  WEB->>API: API-006 OP-050 Submit review decision
  CC->>WEB: Work tasks (SC-013)
  WEB->>API: API-005 OP-040 Update task statuses/outcomes
```
