# Workflow Inventory: ForEachHealth_InHomeNPVisitApp_Assessments

## Inventory table
| Workflow ID | Name | Primary Actor(s) | Key Inputs | Key Outputs |
|---|---|---|---|---|
| WF-001 | Pre-Visit Preparation | NP | Member history, plan targets, required checklist, rule pack | Offline prefetch bundle, readiness marker |
| WF-002 | In-Home Intake + Assessments/Measures | NP | Offline bundle, in-visit observations, assessment configs | Draft note, scored assessments, measure results, task drafts |
| WF-003 | Close-Out + Finalize + Integrations | NP, Ops | Draft record, gating rules | Finalized record, FHIR submit tx, export artifact, tasks |
| WF-004 | Clinical Review + Care Coordination | Supervisor, Care Coordinator | Finalized record, completeness score | Approval/corrections, task outcomes |
| WF-005 | Config & Versioning | Technical Admin | Instrument/measure definitions, rule packs | Published versioned configs |
| WF-006 | Compliance & Audit | Compliance Admin | Audit events, access reviews | Audit reports, policy enforcement evidence |

---

## WF-001 ordered steps
1. Authenticate user session (OIDC)
2. Retrieve visit list for NP
3. Retrieve pre-visit bundle for a visit (PHI + checklist + flags)
4. Render pre-visit summary screen
5. Encrypt and store offline cache
6. Mark visit as "Ready" (sync when online)

## WF-002 ordered steps
1. Confirm identity and record verification method
2. Display required checklist (assessments + measures)
3. Capture vitals and exam findings
4. Administer required assessments (PRAPARE, PHQ-2, PHQ-9, AWV)
5. Evaluate required HEDIS measures and capture evidence metadata
6. Run rules engine continuously; store recommendations + rationale + overrides
7. Draft care plan and tasks
8. Save draft locally; sync deltas when online

## WF-003 ordered steps
1. Run final gating validation (block signature if incomplete required items)
2. Capture attestation + signature metadata
3. Finalize record and lock editing (amendments via addendum)
4. Sync to backend and persist version
5. Create care coordination tasks and assign to queue
6. Submit to EMR via FHIR bundle job
7. Generate export file and publish secure download link
8. Track end-to-end status with trace id

## WF-004 ordered steps
1. Supervisor reviews completeness, note quality, evidence metadata
2. Supervisor approves or requests correction
3. Care coordinator executes tasks and referrals
4. Record outcomes with timestamps and provenance
5. Ops optionally packages client outputs (prototype minimal)

## WF-005 ordered steps
1. Create/update assessment instrument definition (versioned)
2. Create/update HEDIS measure definitions (versioned)
3. Manage unable-to-assess reason sets (versioned)
4. Manage plan packs mapping visit type -> required checklist + rule pack
5. Publish version and maintain audit trail

## WF-006 ordered steps
1. Capture PHI access events for every view/download/edit
2. Provide audit report views to compliance roles
3. Enforce retention policies and export access controls
4. Support incident investigation with trace ids and payload hashes
