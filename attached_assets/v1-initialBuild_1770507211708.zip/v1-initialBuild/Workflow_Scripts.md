# Workflow Scripts: ForEachHealth_InHomeNPVisitApp_Assessments

## Conventions
- Workflow IDs: WF-001 ... WF-006
- Screen IDs: SC-### (see App Screen Map)
- API operations reference: API-### / OP-### (see API Library)
- All workflows must capture provenance for each captured datum: entered_by, entered_at, source_type, device_id, instrument_version, rule_pack_version

---

## WF-001 Pre-Visit Preparation (NP Ready View)
**Primary actor:** Nurse Practitioner  
**Goal:** Equip the NP with a complete clinical picture and a required checklist of assessments and HEDIS measures for the visit.

### Preconditions
1. NP authenticated (API-001 OP-001)
2. Visit exists and is assigned to NP
3. Prefetch bundle available for offline use (API-002 OP-002)

### Steps
1. NP opens **SC-001 Login** and authenticates.
2. NP selects the scheduled visit in **SC-002 Visit List**.
3. App loads **Pre-Visit Bundle** (member demographics, history, plan targets, care gaps, risk flags, required checklist).
4. App renders **SC-003 Pre-Visit Summary**:
   - Member banner and identifiers
   - Plan priorities and required items checklist
   - Conditions, meds, allergies, utilization highlights
   - Safety alerts and suggested visit checklist/time plan
5. NP acknowledges readiness and triggers **Offline Prefetch** for the visit (stores encrypted locally).

### Outputs
- Local encrypted cache of the pre-visit bundle
- "Ready" status marker for the visit (sync when online)

### Handoffs
- User -> UI: NP review and acknowledgement
- UI -> Backend: Prefetch retrieval (API-002 OP-002)
- Backend -> External: None

---

## WF-002 In-Home Intake + Assessments/Measures + Recommendations
**Primary actor:** Nurse Practitioner  
**Goal:** Capture clinical findings, administer required assessments and measures, and generate explainable recommendations.

### Preconditions
- Visit is in Draft state and available offline

### Steps
1. NP confirms member identity in **SC-004 Identity Verification** (photo ID, DOB, etc).
2. App opens **SC-005 Intake Home** and displays the required checklist (Assessments + Measures).
3. NP completes vitals and exam quick capture in **SC-006 Vitals + Exam**.
4. NP administers program assessments:
   - PRAPARE (**SC-007 Assessment Runner**)
   - PHQ-2 / PHQ-9 (**SC-007**)
   - AWV components (**SC-007**)
5. NP evaluates each member-specific HEDIS measure item in **SC-008 HEDIS Measure Tasks**.
6. Rules engine updates recommendations in real time and records each decision point:
   - Rule id/version, triggering facts, rationale, suggested actions (API-003 OP-010)
7. NP documents Assessment/Plan and drafts follow-up tasks in **SC-009 Care Plan + Tasks**.
8. At any point, NP may mark a required item as **Unable to Assess** with a structured reason.

### Outputs
- Draft clinical note sections (HPI/ROS/Exam/Assessment/Plan)
- Completed assessment responses and scores (versioned)
- Measure evaluation results with evidence metadata
- Task drafts for care coordination

### Handoffs
- UI -> Backend: Draft save (API-002 OP-004) when online; otherwise local queue
- Backend -> External: None during offline; queued submissions after finalize

---

## WF-003 Close-Out + Finalization Gating + Sync + EMR Submit + Export
**Primary actor:** Nurse Practitioner  
**Goal:** Validate completeness, sign the chart, sync records, and trigger EMR submission + export generation.

### Preconditions
- Identity verified
- Draft content exists

### Steps
1. NP opens **SC-010 Review & Finalize**.
2. App runs finalization gating checks:
   - All required checklist items are either completed or have structured unable-to-assess reasons
   - Required fields by plan are present
   - Signature/attestation captured
3. If gating fails, UI blocks finalization and deep-links to missing items.
4. If gating passes, NP signs and finalizes.
5. App syncs to backend (API-002 OP-006). Backend persists and versions the record.
6. Backend queues EMR submission job (API-004 OP-020) and export generation job (API-004 OP-030).
7. Web app shows status in **SC-012 Visit Detail (Web)** and makes export downloadable after completion (API-004 OP-031).

### Outputs
- Finalized visit record
- EMR submission transaction record
- Export artifact (FHIR bundle JSON)
- Created care coordination tasks (API-005 OP-040)

### Handoffs
- Mobile -> Backend: Finalize + sync
- Backend -> External: EMR FHIR endpoint submit (FHIR transaction bundle)
- Backend -> Web: status + download link

---

## WF-004 Clinical Review + Care Coordination
**Primary actors:** Clinical Supervisor, Care Coordinator  
**Goal:** Review completeness/quality, execute tasks/referrals, and document outcomes.

### Steps
1. Supervisor opens review queue **SC-011 Supervisor Review Queue (Web)**.
2. Supervisor reviews note, checklist completeness, evidence metadata, and audit trail.
3. Supervisor either approves or requests correction (API-006 OP-050).
4. Care coordinator works tasks in **SC-013 Care Coordination Workspace (Web)**:
   - Assign owners, due dates, outcomes
   - Record attempted contacts and completed referrals
5. Ops generates client package exports if needed (prototype minimal).

---

## WF-005 Configuration & Versioning (Admin)
**Primary actor:** Technical Admin  
**Goal:** Configure plan packs, assessment instruments, measures, and rule packs with strict versioning.

### Steps
1. Admin manages plan configurations in **SC-014 Admin Console (Web)**.
2. Admin versions:
   - Instruments (PRAPARE/PHQ/AWV) with scoring rules
   - HEDIS measure definitions (identifiers, evidence expectations, capture methods)
   - Unable-to-assess reason sets
   - Rule packs (recommendations + gating)
3. Publish new version -> available to mobile on next sync; server wins for configuration conflicts.

---

## WF-006 Compliance: Audit + Access + Retention
**Primary actor:** Compliance Admin  
**Goal:** Ensure PHI access is auditable and controls are enforceable.

### Steps
1. Compliance views audit reports in **SC-015 Compliance Audit Viewer (Web)**.
2. Access reviews and break-glass events are reviewed with justifications.
3. Retention policies and export access logs reviewed.

